
import csv
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from Tools.scripts.dutree import display
from scipy.signal import find_peaks

# df = pd.read_csv('WALKING.csv')
# print(df.columns)

with open('WALKING_AND_TURNING.csv','r') as f:
    reader = csv.reader(f)
    column = [row[11] for row in reader]

    y = np.array(column)
    x = y.astype(np.float)

peaks2, _ = find_peaks(x, prominence=1)
peaks3, _ = find_peaks(x, width=20)  #better !!!!!!!!!

plt.subplot(2, 2, 1)
plt.plot(peaks2, x[peaks2],"ob"); plt.plot(x); plt.legend(['prominence'])
plt.subplot(2, 2, 2)
plt.plot(peaks3, x[peaks3],"vg"); plt.plot(x); plt.legend(['width'])
plt.show()